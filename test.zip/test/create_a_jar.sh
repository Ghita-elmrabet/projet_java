#!/bin/bash

make release
cd build/main/grid
jar cfe ourconnect.jar ourconnect/Main *.class
 #nom du fichier .jar #nom de la classe principale #liste des fichiers .class
cd ../../..
cp build/main/grid/ourconnect.jar ourconnect.jar #nom du fichier.jar #nom du fichier .jar
